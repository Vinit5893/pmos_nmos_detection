# Circuit Recognition Electronics > Flip rotate 500x500
https://universe.roboflow.com/rp-project/circuit-recognition-electronics

Provided by a Roboflow user
License: MIT

