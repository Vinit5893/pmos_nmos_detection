# component detection > 2023-11-25 8:10pm
https://universe.roboflow.com/crescent-university/component-detection-vygsu

Provided by a Roboflow user
License: CC BY 4.0

